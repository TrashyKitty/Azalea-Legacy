
const fs = require('fs');
const path = require('path');
const { minify } = require('terser');

const inputDir = './src';
const outputDir = './build';

const walkSync = (dir, fileList = []) => {
  fs.readdirSync(dir).forEach((file) => {
    const filePath = path.join(dir, file);
    if (fs.statSync(filePath).isDirectory()) {
      fileList = walkSync(filePath, fileList);
    } else {
      fileList.push(filePath);
    }
  });
  return fileList;
};

const files = walkSync(outputDir);

for (const file of files) {
  if (path.extname(file) === '.js') {
    const code = fs.readFileSync(file, 'utf8');
    minify(code)
      .then((result) => {
        const outputPath = path.join(outputDir, path.relative(inputDir, file));
        fs.mkdirSync(path.dirname(outputPath), { recursive: true });
        fs.writeFileSync(outputPath, result.code, 'utf8');
      })
      .catch((error) => {
        console.error(`Failed to minify ${file}: ${error}`);
      });
  }
}