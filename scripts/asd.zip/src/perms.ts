export const RankPermissions = {
    CanUseAdminPanel: 0,
    CanManageWarps: 1,
    CanManageRanks: 2,
    CanManagePermissions: 3,
    AdminWarpBypass: 4,
    CanChangeNameTagColor: 5,
};
