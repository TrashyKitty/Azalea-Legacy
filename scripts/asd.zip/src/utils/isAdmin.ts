// Will be used for customizable admin permissions later
export function isAdmin(player) {
    return player.isOp();
}
