export const Tables = {
    CustomCommands: 0,
    PlayerReports: 1,
    Reviews: 2,
    ModMail: 3,
    OfflineAdmins: 4,
    AzaleaData: 5,
    Bans: 6,
    Warns: 7,
    ChatSettings: 8,
    RankPerms: 9,
    Nicknames: 10,
    Leaderboards: 11
};
