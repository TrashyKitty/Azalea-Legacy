const cacheNormal = new Map();
const cache = new Proxy(cacheNormal, {
    get(target, propKey:any, receiver) {
      console.log(`[CACHE] Read operation: ${propKey}`);
      return Reflect.get(target, propKey, receiver);
    },
  
    set(target, propKey:any, value, receiver) {
      console.log(`[CACHE] Write operation: ${propKey} = ${value}`);
      return Reflect.set(target, propKey, value, receiver);
    }
  });

export { cache as cacheNormal };
export { cacheNormal as cache };