export const SuccessTestCommand = {
    name: "success",
    description: "SUCCESS TEST",
    category: "Tests",
    exec(msg, args) {
        return "success Command somehow worked!";
    },
};
