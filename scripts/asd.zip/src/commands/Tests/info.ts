export const InfoTestCommand = {
    name: "info",
    description: "INFO TEST",
    category: "Tests",
    exec(msg, args) {
        return "info School is hell!";
    },
};
