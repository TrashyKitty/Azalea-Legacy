// This file is a redesign of the original main.ts file, the code is more clean in my opinion.
// Have fun!


// @ts-ignore
import * as minecraft from "@minecraft/server";
// @ts-ignore
import * as ui from "@minecraft/server-ui";
import { WildCommand } from "./commands/Garbage/wild";
import { AboutAzaleaCommand } from "./commands/Information/about";
import { CreditsCommand } from "./commands/Information/credits";
import { HelpCommannd } from "./commands/Information/help";
import { TutorialsCommand } from "./commands/Information/tutorials";
import { Warp } from "./commands/Information/warp";
import { WarpCommand } from "./commands/Information/warpCmd";
import { loadTagCmd, TagCMD } from "./commands/tagcmd/tagcmd";
import { DbGetCommand } from "./commands/Tests/dbget";
import { DbSetCommand } from "./commands/Tests/dbset";
import { ErrorTestCommand } from "./commands/Tests/error";
import { idgrabber } from "./commands/Tests/grabids";
import { InfoTestCommand } from "./commands/Tests/info";
import { AddLeaderboardCommand } from "./commands/Tests/lbadd";
import { NicknameCommand } from "./commands/Tests/nickname";
import { idgrabber2 } from "./commands/Tests/resetnicknames";
import { SuccessTestCommand } from "./commands/Tests/success";
import { WarnCommand } from "./commands/Tests/warn";
import { Database } from "./db";
import { azaleaEnv } from "./env"
import { nautilus } from "./modules/nautilus/nautilus";
import { NicknamesModule } from "./modules/nicknames";
import { Tables } from "./tables";
import { StaffchatCommand } from "./utils/staffchat";
import { cache } from "./cache";
import { NautilusResourcesCommand } from "./modules/nautilus/commands/resources";
// @ts-ignore
import { MessageFormData } from "@minecraft/server-ui";

cache.set("commands", new Map());
const toggles: number[] = [1 << 0, 1 << 1, 1 << 2, 1 << 3];

(function () {
    let commandsMap = cache.get("commands");
    const commands = [
        CreditsCommand,
        InfoTestCommand,
        ErrorTestCommand,
        SuccessTestCommand,
        HelpCommannd,
        WildCommand,
        DbSetCommand,
        DbGetCommand,
        NicknameCommand,
        AboutAzaleaCommand,
        WarnCommand,
        TutorialsCommand,
        StaffchatCommand,
        TagCMD
    ];
    for (const command of commands) {
        commandsMap.set(command.name, command);
    }
    cache.set("commands", commandsMap);


})()

// nautilus(cache.get('commands').values(), azaleaEnv);
let db11 = new Database(11);

let messagesCache = db11.keys();

function messageDataToMessage(data) {
    let username = data.username,
        ranks = data?.ranks?.length ? data.ranks : ["§bMember"],
        nameColor = data?.nameColor ? data.nameColor : "§b",
        bracketColor = data?.bracketColor ? data.bracketColor : "§8",
        messageColor = data?.messageColor ? data.messageColor : "§r",
        suffix = data?.suffix ? ` §o${data.suffix}§r` : "",
        prefix = data?.prefix ? `§o${data.prefix}§r ${nameColor}` : ``,
        message = data.message;
    let rankBracket = [`§l${bracketColor}[§r`, `§r${bracketColor}§l]`]
    let ranksJoined = `${rankBracket[0]}${ranks.join('§r§7, ')}${rankBracket[1]}`;
    return `${ranksJoined} §r${nameColor}${prefix}${username}${suffix}${bracketColor}: ${messageColor}${message}`;
}

function getTagsWithStartsWith(player, start: string, all: boolean = false, remove: boolean = false) {
    let tags = player.getTags();
    let foundTags = tags.filter(tag => tag.startsWith(start));

    if (remove) foundTags = foundTags.map(tag => tag.substring(start.length));
    if (!all) foundTags = foundTags[0];

    return foundTags;
}

minecraft.world.events.playerJoin.subscribe((eventData) => {
    const { playerId, playerName } = eventData;
    let loop = minecraft.system.runInterval(() => {
        for (const player of minecraft.world.getPlayers()) {
            if (player.id != playerId) continue;
            minecraft.system.runTimeout(() => {
                // console.warn(messagesCache);
                let messagesCacheSorted = messagesCache.sort((a, b) => parseInt(a) - parseInt(b));
                if (messagesCacheSorted.length > 40) {
                    let toRemove = messagesCacheSorted.slice(0, messagesCacheSorted.length - 40);
                    for (const remove of toRemove) {
                        console.warn(remove);
                        minecraft.world.scoreboard.removeObjective(`VAL11${remove}`);
                        messagesCacheSorted = messagesCacheSorted.slice(1);
                    }
                }
                for (const message of messagesCacheSorted) {
                    let data = db11.get(message);
                    console.warn(data);
                    try {
                        player.sendMessage(`§8§l[§aSAVED§8]§r ` + messageDataToMessage(JSON.parse(data)));
                    } catch {
                        player.sendMessage(`§8§l[§aSAVED§8] §cERROR`);
                    }
                }
                messagesCache = db11.keys();
            }, 20);
            minecraft.system.clearRun(loop);
        }
    }, 40);
})

let chatRanksEnabled = true;

minecraft.system.events.scriptEventReceive.subscribe(async e=>{
    console.warn("AAAA");
    if(e.id.startsWith('azalea:')) {
        let messageId = e.id.replace('azalea:', '')
        let message = e.message;
        if(messageId == "broadcast") {

            minecraft.world.sendMessage(messageDataToMessage({
                message,
                username: "BROADCAST",
                ranks: ["§aAzalea"],
                nameColor: "§a",
                bracketCOlor: "§b",
                messageColor: "§3"
            }))
        }
        if(messageId == "batch-cmds") {
            if(e.sourceType == "commandBlock") {
                let commands = message.split(' ; ');
                for(let i = 0;i < commands.length;i++) {
                    if(commands[i].startsWith('broadcast ')) {
                        minecraft.world.sendMessage(messageDataToMessage({
                            "message": commands[i].split(' ').slice(1).join(' '),
                            username: "BROADCAST",
                            ranks: ["§aAzalea"],
                            nameColor: "§a",
                            bracketCOlor: "§b",
                            messageColor: "§3"
                        }))
                    } else {
                        await minecraft.world.getDimension('overworld').runCommandAsync(commands[i]);
                    }
                }
            }
        }
        if(messageId == "list-players") {
            try {
                let players = await minecraft.world.getPlayers();
                let playerNames = [];
                for(const player of players) {
                    playerNames.push(`§3${player.name} ${player.isOp() ? '§a(ADMIN)' : '§c(MEMBER)'}`);
                }
                if(e.sourceType == "commandBlock") {
                    minecraft.world.sendMessage(`§bPlayer list: §r${playerNames.join('§8, §r')}`);
                } else {
                e.sourceEntity.sendMessage(`§8§l<§dPRIVATE§8> §r§bPlayer list: §r${playerNames.join('§8, §r')}`);

                }    
            } catch(err) {
                console.warn(err);
            }
        }
    };
    if(e.id.startsWith('azalea-cmd:')) {
        console.warn(e.sourceType);
        if(e.sourceType == "clientScript") {
            let cmd = e.id.replace('azalea-cmd:', '');
            console.warn(cmd);
            let cmds = cache.get('commands');
            if(cmds.has(cmd)) {
                let cmdData = cmds.get(cmd);
                console.warn(cmdData);
                cmdData.exec({
                    sender: e.sourceEntity,
                    message: `!${cmd} ${e.message}`,
                    cancel: true
                }, e.message ? e.message.split(' ') : [], Array.from(cmds.values()), {a: 0}, azaleaEnv);
            }
        }
    }
    if(e.id == 'azalea-experiments:yesno') {
        let sections = e.message.split(' ; ');
        let ui = new MessageFormData().body(sections[0]).title(sections[1]).button1("Yes").button2("No");
        let customID = sections[2];
        ui.show(e.sourceEntity).then(response=>{
            e.sourceEntity.addTag(`YESNO_RESPONSE:${customID}:${response.selection}`);
            e.sourceEntity.addTag(`YESNO_RESPONSE:${customID}`);
        })
    }
})

minecraft.world.events.beforeChat.subscribe((msg) => {
    if (msg.message.startsWith('!')) {
        msg.cancel = true;
        let command = msg.message
            // get everything before the first space, if any
            .split(' ')[0]
            // remove first character
            .substring(1);
        let args = msg.message
            // separate string by space
            .split(' ')
            // remove first element
            .slice(1);
        if (cache.get("commands").has(command)) {
            let response = cache.get("commands").get(command).exec(msg, args, Array.from(cache.get('commands').values()), { a: 0 }, azaleaEnv);
        } else {
            msg.sender.sendMessage("§cUnknown command!")
        }

        msg.sender.sendMessage("§a> §d" + msg.message);
    } else if (!msg.message.startsWith('!') && chatRanksEnabled) {
        msg.cancel = true;

        let ranks = getTagsWithStartsWith(msg.sender, "rank:", true, true);
        if (!ranks.length) ranks = ["§bMember"];

        let nameColor = getTagsWithStartsWith(msg.sender, "name-color:", false, true);
        if (!nameColor) nameColor = "§b";

        let messageData = {
            nameColor,
            ranks,
            message: msg.message,
            username: msg.sender.nameTag,
            bracketColor: "§d",
            messageColor: "§a",
            suffix: "SUFFIX"
        }
        db11.set(Date.now().toString(), JSON.stringify(messageData))


        minecraft.world.sendMessage(messageDataToMessage(messageData))
    }
})