// @ts-ignore
import {world} from '@minecraft/server';

export class Economy {
    moneyScoreboardLarge: string;
    moneyScoreboardSmall: string;
    constructor() {
        this.moneyScoreboardLarge = "money_large";
        this.moneyScoreboardSmall = "money_small"
    }

    convertToSmall(num) {
        return num / Math.pow(10, num.toString().length);
    }

    convertToLarge(num) {
        return num * Math.pow(10, num.toString().substring(2).length);
    }

    getAmount(player) {
        let scoreboard_large = world.scoreboard.getObjective('money_large');
        let scoreboard_small = world.scoreboard.getObjective('money_small');

        let participants_large = scoreboard_large.getParticipants();
        let participants_small = scoreboard_small.getParticipants();

        let score_large = 0;
        let score_small = 0;

        for(const participant of participants_large) {
            if(participant.displayName == player.name) {
                score_large = participant.getScore();
                break;
            }
        }

        for(const participant of participants_small) {
            if(participant.displayName == player.name) {
                score_small = participant.getScore();
                break;
            }
        }

        return score_large + score_small;
    }
}